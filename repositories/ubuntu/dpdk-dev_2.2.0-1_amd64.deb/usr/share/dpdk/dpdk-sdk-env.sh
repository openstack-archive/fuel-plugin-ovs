export RTE_TARGET="$(uname -m)-default-linuxapp-gcc"
export RTE_SDK="/usr/share/dpdk/"
export RTE_INCLUDE="/usr/include/dpdk"
